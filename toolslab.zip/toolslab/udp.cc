#include "ns3/coremodule.h"
#include "ns3/networkmodule.h"
#include "ns3/internetmodule.h"
#include "ns3/applicationsmodule.
#include "ns3/pointtopointmodule.h"
using namespace ns3;
int main (int argc, char *argv[])
{
// Create nodes
NodeContainer nodes;
nodes.Create (2);
// Install internet stack on nodes
InternetStackHelper stack;
stack.Install (nodes);
// Set up the network topology
PointToPointHelper pointToPoint;
pointToPoint.SetDeviceAttribute ("DataRate", StringValue ("5Mbps"));
pointToPoint.SetChannelAttribute ("Delay", StringValue ("2ms"));
NetDeviceContainer devices = pointToPoint.Install (nodes);
// Assign IP addresses
Ipv4AddressHelper address;
address.SetBase ("10.1.1.0", "255.255.255.0");
Ipv4InterfaceContainer interfaces = address.Assign (devices);
// Create and install UDP server application on node 1
uint16_t port = 9;
PacketSinkHelper sinkHelper ("ns3::UdpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (),
port));
ApplicationContainer serverApps = sinkHelper.Install (nodes.Get (1));
serverApps.Start (Seconds (1.0));
serverApps.Stop (Seconds (10.0));
// Create and install UDP client application on node 0
UdpEchoClientHelper clientHelper (interfaces.GetAddress (1), port);
clientHelper.SetAttribute ("MaxPackets", UintegerValue (1));
clientHelper.SetAttribute ("Interval", TimeVa lue (Seconds (1.0)));
clientHelper.SetAttribute ("PacketSize", UintegerValue (1024));
ApplicationContainer clientApps = clientHelper.Install (nodes.Get (0));
clientApps.Start (Seconds (2.0));
clientApps.Stop (Seconds (10.0));
// Output IP address es
std::cout << "Client IP Address: " << interfaces.GetAddress (0) << std::endl;
std::cout << "Server IP Address: " << interfaces.GetAddress (1) << std::endl;

// Run the simulation
Simulator::Run ();
// Output simulation completion
std::cout << "Simulation completed." << std::
Simulator::Destroy ();
return 0;
}