#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#define N 300
void sequential_matrix_multiplication(int A[N][N], int B[N][N], int C[N][N]) {
int i, j, k;
for (i = 0; i < N; i++) {
for (j = 0; j < N; j++) {
C[i][j] = 0;
}
}
for (i = 0; i < N; i++) {
for (j = 0; j < N; j++) {
for (k = 0; k < N; k++) {
C[i][j] += A[i][k] * B[k][j];
}
}
}
}
void parallel_matrix_multiplication(int A[N][N], int B[N][N], int C[N][N]) {
int i, j, k;
for (i = 0; i < N; i++) {
for (j = 0; j < N; j++) {
C[i][j] = 0;
}
}
#pragma omp parallel for private(i, j, k) shared(A, B, C)
for (i = 0; i < N; i++) {
for (j = 0; j < N; j++) {
for (k = 0; k < N; k++) {
C[i][j] += A[i][k] * B[k][j];
}
}
}
}
void print_matrix(int matrix[N][N]) {
for (int i = 0; i < N; i++) {
for (int j = 0; j < N; j++) {
printf("%d ", matrix[i][j]);
}
printf("\n");
}
}
int main() {
int A[N][N], B[N][N], C_seq[N][N], C_par[N][N];
double start_time, end_time;
for (int i = 0; i < N; i++) {
for (int j = 0; j < N; j++) {
A[i][j] = rand() % 10;
B[i][j] = rand() % 10;
}
}
start_time = omp_get_wtime();
sequential_matrix_multiplication(A, B, C_seq);
end_time = omp_get_wtime();
printf("Time taken for sequential matrix multiplication: %f seconds\n",
end_time - start_time);
start_time = omp_get_wtime();
parallel_matrix_multiplication(A, B, C_par);
end_time = omp_get_wtime();
printf("Time taken for parallel matrix multiplication: %f seconds\n",
end_time - start_time);
printf("Element C[0][0]: %d\n", C_par[0][0]);
printf("Element C[100][100]: %d\n", C_par[100][100]);
printf("Element C[N-1][N-1]: %d\n", C_par[N-1][N-1]);
return 0;
}