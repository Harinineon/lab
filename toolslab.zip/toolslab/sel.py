import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up the WebDriver
driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))

try:
    # Measure page load time
    start_time = time.time()
    driver.get("https://the-internet.herokuapp.com/login")
    end_time = time.time()
    page_load_time = end_time - start_time
    print(f"Page Load Time: {page_load_time:.2f} seconds")

    # Locate the username and password fields
    username_field = driver.find_element(By.ID, "username")
    password_field = driver.find_element(By.ID, "password")

    # Enter the credentials
    entered_username = "tomsmith"
    entered_password = "SuperSecretPassword!"
    username_field.send_keys(entered_username)
    password_field.send_keys(entered_password)

    # Submit the form
    login_button = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
    login_button.click()

    # Measure interaction time
    start_time = time.time()
    # Wait until the success message is visible
    success_message = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, ".flash.success"))
    )
    end_time = time.time()
    interaction_time = end_time - start_time
    print(f"Interaction Time: {interaction_time:.2f} seconds")

    # Check if the success message contains the expected text
    assert "You logged into a secure area!" in success_message.text
    print("Login successful: You logged into a secure area!")

except Exception as e:
    print(f"An error occurred: {e}")

finally:
    # Close the browser after the test
    driver.quit()
