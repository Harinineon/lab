#include "ns3/coremodule.h"
#include "ns3/networkmodule.h"
#include "ns3/internetmodule.h"
#include "ns3/applicationsmodule.h"
#include "ns3/pointtopointmodule.h"
using namespace ns3;
int main (int argc, char *argv[])
{
// Create nodes
NodeContainer nodes;
nodes.Create (2);
// Install internet stack on nodes
InternetStackHelper stack;
stack.Install (nodes);
// Se t up the network topology
PointToPointHelper pointToPoint;
pointToPoint.SetDeviceAttribute ("DataRate", StringValue ("5Mbps"));
pointToPoint.SetChannelAttribute ("Delay", StringValue ("2ms"));
NetDeviceContainer devices = pointToPoint.Install (nodes);
// Assign IP addresses
Ipv4AddressHelper address;
address.SetBase ("10.1.1.0", "255.255.255.0");
Ipv4InterfaceContainer interfaces = address.Assign (devices);
// Create and install TCP server application on node 1
uint16_t port = 9;
PacketSinkHelper sinkHelper ("ns3::TcpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), port));
ApplicationContainer serverApps = sinkHelper.Install (nodes.Get (1));
serverApps.Start (Seconds (1.0));
serverApps.Stop (Seconds (10.0));
//// Create and install TCP client application on node 0Create and install TCP client application on node 0
BulkSendHelper clientHelper ("ns3::TcpSocketFactory", InetSocketAddress (interfaces.GetAddress (1), port));
clientHelper.SetAttribute ("MaxBytes", UintegerValue (0));
clientHelper.SetAttribute ("SendSize", UintegerValue (1024));
ApplicationContainer clientApps = clientHelper.Install (nodes.Get (0));
clientApps.Start (Seconds (2.0));
clientApps.Stop (Seconds (10.0));
// Output IP addresses// Output IP addresses
std::cout << "Client IP Address: " << interfaces.GetAddress (0) << std::endl;
std::cout << "Server IP Address: " << interfaces.GetAddress (1) << std::endl;
// Run the simulation// Run the simulation
Simulator::Run ();
// Output simulation completion// Output simulation completion
std::cout << "Simulation completed." << std::endl;
Simulator::Destroy ();
return 0;

}