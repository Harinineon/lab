from mpi4py import MPI
import numpy as np
INF = np.inf
def floyd_warshall(local_mat, n, local_n, rank, size):
    row_k = np.zeros(n)
    for k in range(n):
        root = k // local_n
        if rank == root:
            row_k[:] = local_mat[k % local_n, :]
        MPI.COMM_WORLD.Bcast(row_k, root=root)
        
        for i in range(local_n):
            for j in range(n):
                if local_mat[i, k] != INF and row_k[j] != INF:
                    local_mat[i, j] = min(local_mat[i, j], local_mat[i, k] + row_k[j])

def main():
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    
    if rank == 0:
        n = int(input("Enter the number of vertices: "))
        mat = np.zeros((n, n))
        print(f"Enter the adjacency matrix (use {INF} for INF):")
        for i in range(n):
            mat[i] = list(map(float, input().split()))
    else:
        n = None
        mat = None

    n = comm.bcast(n, root=0)
    local_n = n // size
    local_mat = np.zeros((local_n, n))
    comm.Scatter(mat, local_mat, root=0)

    # Start timing here
    comm.Barrier() # Ensure all processes start timing together
    start_time = MPI.Wtime()

    # Repeat the Floyd-Warshall algorithm multiple times to get an average time
    repetitions = 100
    for _ in range(repetitions):
        floyd_warshall(local_mat, n, local_n, rank, size)

    # End timing here
    comm.Barrier() # Ensure all processes finish before stopping the timer
    end_time = MPI.Wtime()
    elapsed_time = (end_time - start_time) / repetitions
    
    comm.Gather(local_mat, mat, root=0)
    
    if rank == 0:
        print("Shortest path matrix:")
        for i in range(n):
            for j in range(n):
                if mat[i, j] == INF:
                    print("INF", end=" ")
                else:
                    print(int(mat[i, j]), end=" ")
            print()
        print(f"Elapsed time: {elapsed_time:.8f} seconds")

if __name__ == "__main__":
    main()
